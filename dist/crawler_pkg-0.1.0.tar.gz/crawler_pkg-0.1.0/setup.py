# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['crawler_pkg']

package_data = \
{'': ['*'], 'crawler_pkg': ['data/*']}

install_requires = \
['bs4>=0.0.1,<0.0.2',
 'colorama>=0.4.4,<0.5.0',
 'contractions>=0.1.72,<0.2.0',
 'email-validator>=1.2,<1.3',
 'inflect>=5.6.0,<5.7.0',
 'nltk>=3.7,<3.8',
 'numpy>=1.22,<1.23',
 'pandas>=1.4,<1.5',
 'phonenumbers>=8.12.48,<8.13.0',
 'requests-html>=0.10.0,<0.11.0',
 'requests>=2.27.1,<2.28.0',
 'scipy>=1.8.1,<1.9.0',
 'sklearn',
 'sutime>=1.0.1,<1.1.0',
 'tqdm',
 'urllib3>=1.26.9,<1.27.0']

setup_kwargs = {
    'name': 'crawler-pkg',
    'version': '0.1.0',
    'description': 'a custom webcrawler with NLP tools as plugin',
    'long_description': None,
    'author': 'tariq',
    'author_email': 'tariqmohamed59@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
